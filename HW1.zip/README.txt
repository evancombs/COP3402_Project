COP 3402 Summer A, 2021
HW1 VM Assignment
Evan Combs and Dylan McKim

To compile:  
  gcc vm.c

To run:  
   ./a.out <input file>.txt  
